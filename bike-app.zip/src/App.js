import React, { useState, useRef, useEffect } from 'react'
import Header from './components/Header/Header';
import Footer from './components/Footer/Footer';
import {BrowserRouter, Switch, Route} from 'react-router-dom'
import AboutUs from './components/AboutUs/AboutUs';
import WhereToRide from './components/WhereToRide/WhereToRide';
import Contacts from './components/Contacts/Contacts';
import Rent from './components/Rent/Rent';
import ChooseBike from './components/Rent/ChooseBike/ChooseBike';
import dataBikeTypes from './components/Rent/dataBikeTypes'

function App() {
  const [active, setActive]=useState([]) 
  const itemsRef = useRef([]);
    useEffect(() => {
       itemsRef.current = itemsRef.current.slice(0, dataBikeTypes.length);
    }, [dataBikeTypes]);
    const click=(id, typeName)=>{
        itemsRef.current[id].classList.toggle('activeType')
        active.includes(typeName)===false ? active.push(typeName) : active.splice(active.indexOf(typeName), 1)
        console.log(active)
    }
  return (
    <BrowserRouter>
      <Header />
      <Switch>
        <Route path='/about-us'>
          <AboutUs />
        </Route>
        <Route path='/rent'>
          <Rent active={active} setActive={setActive} itemsRef={itemsRef} click={click}/>
          <Route path={`/rent/choose-bike`}>
            <ChooseBike active={active}/>
          </Route>
        </Route>
        <Route path='/delivery'>
          Delivery
        </Route>
        <Route path='/where-to-ride'>
          <WhereToRide />
        </Route>
        <Route path='/contacts'>
          <Contacts />
        </Route>
      </Switch>
      <Footer />
    </BrowserRouter>
  );
}

export default App;
