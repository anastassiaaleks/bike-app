import React from 'react'

const Data = React.createContext()

export default Data