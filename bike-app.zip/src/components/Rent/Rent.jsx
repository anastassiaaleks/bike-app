import React from 'react'
import './Rent.css'
import promo from './../../assets/img/rent/promo.png'
import dataBikeTypes from './dataBikeTypes'
import Popup from 'reactjs-popup';
import { NavLink } from 'react-router-dom';

const Rent = ({itemsRef, click}) => {    
    const bikeList=dataBikeTypes.map((elem, i)=>{
        return (
            <div key={elem.id} className='bikeTypeItem'>
                <img src={elem.src} alt="" />
                <div className='itemInfo'>
                    <span>{elem.type}</span>
                    <div className='price'>
                        <p>{elem.price} AED</p>
                        <div className='btns'>
                            <Popup
                            trigger={<button className='info'>?</button>}
                            position="bottom center"
                            on={['hover', 'focus']}
                            >
                                <div className='tooltipDiv'>
                                    {elem.addInfo} 
                                </div>
                            </Popup>
                            <button
                             onClick={()=>{click(i, elem.typeName)}}
                             className='add'
                             ref={elem => itemsRef.current[i] = elem} 
                            >+</button>
                        </div>
                    </div>
                </div>
            </div>     
        )
    })
    return (
        <section>
            <div className='promo'>
                <div className='promoTop'>
                    <h1>Аренда велосипедов с доставкой</h1>
                    <img className='gifts' src={promo} alt="" />
                </div>
                {/* <div className={styles.options}>
                    <div className={styles.optionItem}>
                        <span>Доставка</span>
                        <div className={styles.deliveryType}>тип доставки</div>
                    </div>
                </div> */}
            </div>
            <div className='bikes'>
                <h3>Тип велосипеда</h3>
                <div className='bikeTypes'>
                    {bikeList}
                </div>
                <NavLink className='find' to={'/rent/choose-bike'}>Найти</NavLink>
            </div>
        </section>
    )
}

export default Rent