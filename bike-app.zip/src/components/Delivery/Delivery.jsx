import React from 'react'
import * as styles from './Delivery.module.css'

const Delivery = () => {
    return (
        <section>
            <p>Delivery</p>
        </section>
    )
}

export default Delivery